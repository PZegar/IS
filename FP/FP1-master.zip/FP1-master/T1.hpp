#ifndef PHASETRANSITIONT1_HPP
#define PHASETRANSITIONT1_HPP

#include <QtGlobal>

struct T1
{
	qreal temperature;
	qreal enthalpy;
};

#endif // PHASETRANSITIONT1_HPP
